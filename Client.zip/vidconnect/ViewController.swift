//
//  ViewController.swift
//  vidconnect
//
//  Created by Gomathy Shankaran on 2/12/24.
import UIKit
import UIKit
import OpenTok

struct ktable: Decodable
{
   
    var apiKey = String()
    var sessionId = String()
    var tokenId = String()
}
struct mtable: Decodable
{
    var status = String()
   
}
struct etable: Decodable
{
    var message = String()
   
}
struct m1table: Decodable
{
    var message = String()
   
}
// Replace with your OpenTok API key
var kApiKey = ""
var kSessionId = ""
var kToken = "";

class ViewController: UIViewController, OTSessionDelegate {
   
    @IBOutlet var chatsend: UIButton!
    @IBOutlet var chatm: UITextField!
    @IBOutlet var broadc: UILabel!
    var err = ""
    var chatm1 = ""
    var cview = UIView()
    var session: OTSession?
    var publisher: OTPublisher?
    var subscriber: OTSubscriber?
    var pub:UIView?
  //  var publi:OTPublisher?
    @IBOutlet var liveb: UIButton!
    @IBOutlet var vidstart: UIButton!
    var message = ""
    var message1 = ""
    func sessionDidConnect(_ session: OTSession) {
        print("The client connected to the OpenTok session.")
        broadc.text = message
        let settings = OTPublisherSettings()
        settings.name = "GS Video"
        settings.audioTrack = false
        settings.videoTrack = true
        settings.cameraResolution = .high
        settings.cameraFrameRate = .rate30FPS
        guard let publisher = OTPublisher(delegate: self, settings: settings) else {
            return
        }
        self.publisher = publisher
        var error: OTError?
        session.publish(publisher, error: &error)
        guard error == nil else {
            print(error!)
            return
        }

        guard let publisherView = publisher.view else {
           
            return
        }
        pub = publisherView
       // publi = publisher
        let screenBounds = UIScreen.main.bounds
        publisherView.frame = CGRect(x:  20, y: 350, width:screenBounds.width - 50, height: screenBounds.height - 525)
        view.addSubview(publisherView)
        
        if let capabilities = session.capabilities, capabilities.canPublish {
            print("The client can publish")
            self.broadcastvideo()
            
           
            
        } else {
            print("The client cannot publish",session.capabilities!)
            self.broadc.text = "Client cannot publish"
        }
       
    }
    
    
       func sessionDidDisconnect(_ session: OTSession) {
           print("session disconnect",session)
           self.broadc.text = message1
           var error1: OTError?
           session.unpublish(publisher!, error: &error1)
            if let error1 = error1 {
               print("unpublishing failed with error: \(error1)");
            }

           print("The client disconnected from the OpenTok session.")
          
       }
    

       func session(_ session: OTSession, didFailWithError error: OTError) {
           print("The client failed to connect to the OpenTok session: \(error).")
           self.broadc.text = "Broadcast Failed"
       }

    func session(_ session: OTSession, streamCreated stream: OTStream) {
     
    }
       func session(_ session: OTSession, streamDestroyed stream: OTStream) {
           pub!.removeFromSuperview()
           print("A stream was destroyed in the session.")
           self.broadc.text = "Broadcast Stream Distroyed"
       }
    
   
    override func viewDidLoad() {
      //  cview.largeContentTitle = "YouTube Stream"
        
     //   cview.frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.width - 20, height: UIScreen.main.bounds.height - 20)
     //   cview.backgroundColor = UIColor(red: 0.5, green: 0.5, blue: 0.5, alpha: 1)
    //    view.addSubview(cview)
        super.viewDidLoad()
        
      //  connectToAnOpenTokSession()
        
        }
    @IBAction func livb(_ sender: UIButton) {
      
      
        if  (session?.sessionConnectionStatus == nil)
        {
            let alert =  UIAlertController(title: "Broadcast Message", message: "There is no Broadcast to Stop", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: NSLocalizedString("OK", comment: "Default action"), style: .default, handler: { _ in
                NSLog("The \"OK\" alert occured.")
            }))
            self.present(alert, animated: true, completion: nil)
        }
        else {
           
           
            print("pressed inside")
            let url2 = URL(string: "https://erffqoltxb.execute-api.us-east-1.amazonaws.com/latest/stopBroadcast?format=json")
            print("url2",url2!)
        //    UIApplication.shared.beginBackgroundTask() {
          //  if UIApplication.shared.canOpenURL(url2!) {
              //  DispatchQueue.main.asyncAfter(deadline: .now(),qos: .background) {
                   
           // UIApplication.shared.open(url2!, options: [:], completionHandler: { (success) in
                            
                           
                            URLSession.shared.dataTask(with: url2!){(data1,reponse,error) in
                                do
                                {
                                    if let data1 = data1 {
                                        let dict1 =  try JSONDecoder().decode(m1table.self, from: data1)
                                        self.message1 = dict1.message
                                        print("dict2 message",self.message1)
                                       
                                      
                                    } // if data = data
                                   
                                }
                                catch
                                {
                                    print("There is an error",error)
                                    kSessionId = "Error"
                                    kToken = "Error"
                                    self.message1 = "Error Stoping"
                                    print("error2 message",self.message1)
                                }
                                
                            }.resume()
                            
                    //    })
                 //   }
              //  }
      //      }
            
          //  var error1: OTError?
           
         //   session!.unpublish(publisher!, error: &error1)
         //   if let error1 = error1 {
         //      print("unpublishing failed with error: \(error1)");
        //    }
            self.pub!.removeFromSuperview()
            var error: OTError?
         
           self.session?.disconnect(&error)
           
          
        } // else
       
    }
    @IBAction func vidstart1(_ sender: UIButton) {
        
        
    }
    @IBAction func vidstart(_ sender: UIButton)  {
        //    view.backgroundColor = UIColor(red: 1.0, green: 0.5, blue: 0.5, alpha: 1)
                         // Do any additional setup after loading the view.
                        // connectToAnOpenTokSession()
                         let configuration = URLSessionConfiguration.default
                         let session = URLSession(configuration: configuration)
                             let url = URL(string: "https://erffqoltxb.execute-api.us-east-1.amazonaws.com/latest/startConnect?format=json")
                 
                 //new
                print(url!)
            //    if UIApplication.shared.canOpenURL(url!) {
                //    DispatchQueue.main.asyncAfter(deadline: .now(),qos: .background) {
                 //       UIApplication.shared.open(url!, options: [:], completionHandler: { (success) in
                            print("inside")
                            URLSession.shared.dataTask(with: url!){(data,reponse,error) in
                                do
                                {
                                    
                                    if  let data = data {
                                    //    print("--> data: \(String(data: data, encoding: .utf8))")
                                        let dict =  try JSONDecoder().decode(ktable.self, from: data)
                                        
                                        print("dict",dict)
                                        //       DispatchQueue.main.asyncAfter(deadline: .now() + 0.2)
                                        //   {
                                        //       self.$ftext.reloadInputViews
                                        //  }
                                        //temp
                                       
                                        kApiKey = dict.apiKey
                                       
                                        kSessionId = dict.sessionId
                                        kToken = dict.tokenId
                                        print("apikey sessionid",kApiKey, kSessionId)
                                        print("tokenid",kToken)
                                        self.message = "Connected"
                                      //  self.connectToAnOpenTokSession()
                                    }// if data = data
                                }
                                catch
                                {
                                    print("There is an error",error)
                                    kSessionId = "Error"
                                    kToken = "Error"
                                    self.message = "Error connecting"
                                }
                                self.connectToAnOpenTokSession()
                            }
                              .resume()
                      //  })
                   // }
                       
             //   }
          
     
    }
    func connectToAnOpenTokSession() {
      print("Kapi",kApiKey)
        print("session",kSessionId)
        print("token",kToken)
       // session = URL
        
        session = OTSession(apiKey: kApiKey, sessionId: kSessionId, delegate: self)
        var error: OTError?
        if (kApiKey == "" || kApiKey == nil || kToken == "Error")
        {
          print("Api Key or Token not found")
            let alert2 =  UIAlertController(title: "Broadcast Message", message: "Key error. Try after sometime.", preferredStyle: .alert)
            alert2.addAction(UIAlertAction(title: NSLocalizedString("OK", comment: "Default action"), style: .default, handler: { _ in
                NSLog("The \"OK\" alert occured.")
            }))
        }
        else
        {
            print("ktoken",kToken)
            
            session!.connect(withToken: kToken, error: &error)
            if error != nil {
                print("Error is ..........", error!)
            }
         //   DispatchQueue.main.asyncAfter(deadline: .now() + 0.5,qos: .background) {
                
           // }
        }
      
    }
    
    @IBAction func chatsend(_ sender: UIButton) {
      //  var connection = OTConnection?.self
        var error: OTError?
        if ((session?.connection) != nil && message != "" )
        {
             chatm1 =  chatm.text!
        //    session?.signal(withType:Data().base64EncodedString(), string: chatm.text,connection: session.connection, error: &error)
          
            session?.signal(withType:"chat", string: chatm1,connection: (session?.connection), error: &error)
            if (error != nil) {
                broadc.text = "Message not sent"
            } else {
                print(error!)
                broadc.text = "Message sent "
               
            }
        }
        else
        {
            broadc.text = "There is no active broadcast"
        }
        
    }
    func broadcastvideo() {
     
        print("pressed inside broadcast")
        let url1 = URL(string: "https://erffqoltxb.execute-api.us-east-1.amazonaws.com/latest/startBroadcast?format=json")!
        print("url1",url1)
        //   URLSession.shared.dataTaskPublisher(for: url!)
     //   if UIApplication.shared.canOpenURL(url1) {
           
          //      UIApplication.shared.open(url1, options: [:], completionHandler: { (success) in
                    print("inside sharedopen")
       
       
                   URLSession.shared.dataTask(with: url1) { (data1,reponse,error) in
                        do
                        {
                          
                            print("inside shared data task")
                            if let data1 = data1 {
                                let dict1 =  try JSONDecoder().decode(mtable.self, from: data1)
                                self.message = "Broadcast " + dict1.status
                                print("dict1 message",dict1.status)
                               
                            } // if data = data
                        }
                        catch {
                            self.message = "Cannot Broadcast"
                         
                                print("error:============ ", error)
                              
                            }
                     
                    }
                    .resume()
     
                
             //   })
          //  }
     //   }
   
        URLSession.shared.finishTasksAndInvalidate()
      
        }
     
    }

   

//}

extension ViewController: OTPublisherDelegate {
   func publisher(_ publisher: OTPublisherKit, didFailWithError error: OTError) {
       print("The publisher failed: \(error)")
       self.broadc.text = message
   }
    func publisher(_ publisher: OTPublisherKit, streamCreated stream: OTStream) {
        print("The publisher stream created",err)
        
      
            self.broadc.text = message
       
    }
}

extension ViewController: OTSubscriberDelegate {
   public func subscriberDidConnect(toStream subscriber: OTSubscriberKit) {
       print("The subscriber did connect to the stream.")
       chatm.text = chatm1
       
   }

   public func subscriber(_ subscriber: OTSubscriberKit, didFailWithError error: OTError) {
       print("The subscriber failed to connect to the stream.")
   }
}

