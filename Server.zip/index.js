'use strict'
var sessionId1 = "";
var token = "";
const express = require('express')
const app = express()
var errorr = ""
var broadcastId
var apiKey
const OpenTok = require("opentok");

const opentok = new OpenTok(process.env.apiKey, process.env.apiSecret);


app.get('/startConnect',(req,res) => {
    opentok.createSession({mediaMode:"routed"}, function(err ,session)  { if (err) {
        console.log("error",err);
        errorr = err;
        res.json({"Message":"There was an error ",errorr})
    }
    else
    {
       
        sessionId1 = session.sessionId;
      
        if (sessionId1 == null || sessionId1 == "" || sessionId1 == undefined || sessionId1 == "Error" )
        {
            sessionId1 = process.env.sessionId
            
           // sessionId1 = sessionId1.trim()
          //  sessionId1 = "1_MX40Nzg1OTA0MX5-MTcwODM4Nzg4MzE4M341MGtpSmJncXhzR0p1Q3crRFJ3VGphUVJ-fn4";
            
           
    }
        const tokenOptions = {};
       
        // we need caption to be moderator role for captions to work
        tokenOptions.role = "moderator";
      //  tokenOptions.expireTime = 1708196720 * 60 * 24 * 7;
        tokenOptions.expireTime = new Date().getTime() / 1000 + 7 * 24 * 60 * 60;
        token = opentok.generateToken(sessionId1, tokenOptions);
       if (token == null || token == "" || token == undefined || token == "Error")
             {
           //   token = "T1==cGFydG5lcl9pZD00Nzg1OTA0MSZzaWc9YjhiOGZiZmY0NmRiZDJjNGE5NThiNzQ4MDE3ZTc1Zjg2OGU1NmY3MjpzZXNzaW9uX2lkPTFfTVg0ME56ZzFPVEEwTVg1LU1UY3dPRE00TnpnNE16RTRNMzQxTUd0cFNtSm5jWGh6UjBwMVEzY3JSRkozVkdwaFVWSi1mbjQmY3JlYXRlX3RpbWU9MTcwODM4NzkwMCZub25jZT0wLjMyOTMzMjg4NDc4NTQxNjY3JnJvbGU9bW9kZXJhdG9yJmV4cGlyZV90aW1lPTE3MTA5NzYzMDAmaW5pdGlhbF9sYXlvdXRfY2xhc3NfbGlzdD0=";
                 
                 token = process.env.tokenId
                 
          //   token = token.trim();
              
             }
        sessionId1 = sessionId1.toString('utf8');
        token = token.toString('utf8');
        apiKey = process.env.apiKey;
        console.log("sess",sessionId1);
        console.log("tok",token);
        console.log("api",apiKey);
        res.json({
            "apiKey": apiKey,
            "sessionId":sessionId1,
            "tokenId":token
        })
    }
    
    })
  //  sessionId1 = this.sessionId1
})
// sessionId1 = "1_MX40Nzg1OTA0MX5-MTcwODM4Nzg4MzE4M341MGtpSmJncXhzR0p1Q3crRFJ3VGphUVJ-fn4"
const broadcastOptions = {
        outputs: {
        rtmp: [{
        id: "Youtube",
        serverUrl:process.env.streamURL,
        streamName:process.env.streamName
        }]
        },
maxDuration: 5000,
resolution: "640X480",
  layout: {
    type: "verticalPresentation",
  },
        };

console.log("inside sessionId1",sessionId1);
console.log("inside token",token);
app.get('/startBroadcast',(req,res) => {
          console.log("inside sart broadcast", sessionId1)
       opentok.startBroadcast(sessionId1, broadcastOptions, async (error, broadcast) => {
           
      //  console.log("broadcast settings",broadcast);
           if (error) {
               console.log('There was an error starting the broadcast',error);
              // res.sendFile('error');
               errorr = "Error"
               res.status(300).send('There was an error');
           }
           else
           {
               
              await app.set('broadcastId', broadcast.id);
               broadcastId = broadcast.id
               console.log('Broadcast object from startBroadcast', broadcast,broadcastId);
              // console.log(sessionId1);
               res.json(broadcast)
              //  res.json({"message":"Broadcast started successfully"});
             //  res.sendFile(broadcast);
           }

});
    
});

app.get('/stopBroadcast',(req,res) => {
        const broadcastId = app.get('broadcastId');
        console.log("broadcastId=======",broadcastId)
    //    opentok.stopBroadcast(broadcastId,(error,broadcast) => {
    console.log("session-id==========",sessionId1);
    opentok.stopBroadcast(sessionId1,  (broadcast) => {
          //  if (error) {
          //      console.log('There was error stopping the broadcast',JSON.parse(JSON.stringify(error)));
          //      res.json(error)
         //   } else {
              //  app.set('broadcastId',broadcast.id);
                app.set('broadcastId', null);
                console.log('broadcast object from stopBroadcast',broadcastId);
       
                res.json({"message":"Broadcast stopped successfully"});
               // res.json(broadcast);
              // return broadcast
         //   }
        });
        
    });

// app.listen(8080, () => console.log("app listening on port 8080"));
module.exports = app; // export your app so aws-serverless-express can use it



