//
//  auth.swift
//  vidconnect
//
//  Created by Gomathy Shankaran on 2/22/24.
//

import Foundation
 class gemil: ObservableObject {
     @Published var  gemail : [String]
   
     init(gemail:String){
         self.gemail = ["gomathyshankaran@gmail.com"]
     }
     
 }
     
