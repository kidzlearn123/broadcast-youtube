//
//  ConnectView.swift
//  vidconnect
//
//  Created by Gomathy Shankaran on 2/21/24.
//

import SwiftUI
import DescopeKit

struct ConnectView: View {
    var flowURL = "https://auth.descope.io/login/P2chbeObwoclAmZIhvq6WeH2EXbb";
    var body: some View {
        ZStack {
            VStack {
                Text("Authenticate")
                Button(action: {
                                   Task.init {
                                       try await startFlow(flowURL: flowURL)
                                           { result, error in
                                               if result == true{}
                                               else {
                                                   if let unwrappedError = error {
                                                       print(unwrappedError)
                                                   }
                                               }
                                           }
                                   }
                               }) {
                                   Text("Get started")
                               }
            }
        }// zstack
       // .background(Color.white)
    }
    
    func startFlow (flowURL: String, completionHandler: @escaping (Bool, DescopeError?) -> Void) async throws {
            Task {
                do {
                    let runner = await DescopeFlowRunner(flowURL: flowURL)
                    let authResponse = try await Descope.flow.start(runner: runner)
                    let session = DescopeSession(from: authResponse)
                    Descope.sessionManager.manageSession(session)
                    completionHandler(true, nil)
                } catch let descopeErr as DescopeError {
                    print(descopeErr)
                    completionHandler(false, descopeErr)
                }
            }
        }
}

#Preview {
    ConnectView()
}
